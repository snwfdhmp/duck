// Project duck [duck managed]
// Class Avalam (src/classes/Avalam/Avalam.class.cpp)
#ifndef AVALAM_CLASS_CPP
#define AVALAM_CLASS_CPP

//Avalam class methods implementation

#include "Avalam.class.hpp"

//class constructor
Avalam::Avalam() {
    // object initialization
}

#endif
