// Project duck [duck managed]
// Class Avalam (src/classes/Avalam/Avalam.class.hpp)
#ifndef AVALAM_CLASS_HPP
#define AVALAM_CLASS_HPP
    
//Avalam class definition

class Avalam
{
public:
    Avalam(); //class constructor
    ~Avalam();
        
};

#endif
