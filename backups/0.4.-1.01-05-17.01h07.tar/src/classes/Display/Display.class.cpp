// Project duck [duck managed]
// Class Display (src/classes/Display/Display.class.cpp)
#ifndef DISPLAY_CLASS_CPP
#define DISPLAY_CLASS_CPP

//Display class methods implementation

#include "Display.class.hpp"

//class constructor
Display::Display() {
    // object initialization
}

#endif
