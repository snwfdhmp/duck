// Project duck [duck managed]
// Class Display (src/classes/Display/Display.class.hpp)
#ifndef DISPLAY_CLASS_HPP
#define DISPLAY_CLASS_HPP
    
//Display class definition

class Display
{
public:
    Display(); //class constructor
    ~Display();
        
};

#endif
