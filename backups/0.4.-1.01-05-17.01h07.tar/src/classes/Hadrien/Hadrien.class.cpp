// Project duck [duck managed]
// Class Hadrien (src/classes/Hadrien/Hadrien.class.cpp)
#ifndef HADRIEN_CLASS_CPP
#define HADRIEN_CLASS_CPP

//Hadrien class methods implementation

#include "Hadrien.class.hpp"

//class constructor
Hadrien::Hadrien() {
    // object initialization
}

#endif
