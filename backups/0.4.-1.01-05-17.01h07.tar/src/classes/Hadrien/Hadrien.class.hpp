// Project duck [duck managed]
// Class Hadrien (src/classes/Hadrien/Hadrien.class.hpp)
#ifndef HADRIEN_CLASS_HPP
#define HADRIEN_CLASS_HPP
    
//Hadrien class definition

class Hadrien
{
public:
    Hadrien(); //class constructor
    ~Hadrien();
        
};

#endif
