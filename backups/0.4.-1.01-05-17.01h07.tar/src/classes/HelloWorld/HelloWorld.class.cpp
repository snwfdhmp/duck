// Project duck [duck managed]
// Class HelloWorld (src/classes/HelloWorld/HelloWorld.class.cpp)
#ifndef HELLOWORLD_CLASS_CPP
#define HELLOWORLD_CLASS_CPP

//HelloWorld class methods implementation

#include "HelloWorld.class.hpp"

//class constructor
HelloWorld::HelloWorld() {
    // object initialization
}

#endif
