// Project duck [duck managed]
// Class HelloWorld (src/classes/HelloWorld/HelloWorld.class.hpp)
#ifndef HELLOWORLD_CLASS_HPP
#define HELLOWORLD_CLASS_HPP
    
//HelloWorld class definition

class HelloWorld
{
public:
    HelloWorld(); //class constructor
    ~HelloWorld();
        
};

#endif
