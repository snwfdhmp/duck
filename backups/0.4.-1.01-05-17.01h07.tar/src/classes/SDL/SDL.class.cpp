// Project duck [duck managed]
// Class SDL (src/classes/SDL/SDL.class.cpp)
#ifndef SDL_CLASS_CPP
#define SDL_CLASS_CPP

//SDL class methods implementation

#include "SDL.class.hpp"

//class constructor
SDL::SDL() {
    // object initialization
}

#endif
