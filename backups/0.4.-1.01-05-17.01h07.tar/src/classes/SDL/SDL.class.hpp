// Project duck [duck managed]
// Class SDL (src/classes/SDL/SDL.class.hpp)
#ifndef SDL_CLASS_HPP
#define SDL_CLASS_HPP
    
//SDL class definition

class SDL
{
public:
    SDL(); //class constructor
    ~SDL();
        
};

#endif
