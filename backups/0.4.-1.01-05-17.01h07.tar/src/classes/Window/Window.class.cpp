// Project duck [duck managed]
// Class Window (src/classes/Window/Window.class.cpp)
#ifndef WINDOW_CLASS_CPP
#define WINDOW_CLASS_CPP

//Window class methods implementation

#include "Window.class.hpp"

//class constructor
Window::Window() {
    // object initialization
}

#endif
