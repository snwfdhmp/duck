// Project duck [duck managed]
// Class Window (src/classes/Window/Window.class.hpp)
#ifndef WINDOW_CLASS_HPP
#define WINDOW_CLASS_HPP
    
//Window class definition

class Window
{
public:
    Window(); //class constructor
    ~Window();
        
};

#endif
