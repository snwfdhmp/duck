// Project duck [duck managed]
// Class test (src/classes/test/test.class.cpp)
#ifndef TEST_CLASS_CPP
#define TEST_CLASS_CPP

//test class methods implementation

#include "test.class.hpp"

//class constructor
test::test() {
    // object initialization
}

#endif
