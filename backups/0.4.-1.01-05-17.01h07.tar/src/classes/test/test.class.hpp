// Project duck [duck managed]
// Class test (src/classes/test/test.class.hpp)
#ifndef TEST_CLASS_HPP
#define TEST_CLASS_HPP
    
//test class definition

class test
{
public:
    test(); //class constructor
    ~test();
        
};

#endif
